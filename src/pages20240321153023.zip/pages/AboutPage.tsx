import LayoutComponent from "../components/LayoutComponent";

const AboutPage: React.FC = () => {
  return (
   <LayoutComponent>
    <h1>About Page</h1>
   </LayoutComponent>
  );
};

export default AboutPage;
