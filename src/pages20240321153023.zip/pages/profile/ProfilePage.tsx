import React, { useEffect, useState } from "react";
import LayoutComponent from "../components/LayoutComponent";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Divider } from "@mui/material";
import PersonalInfo from "./PersonalInfo";
import { isValidEmailAddress } from "../common/CommonFunctions";
import { createPersonalInfoAsync, getPersonalInfoByUserIdAsync } from "../services/PersonalInfoService";
import FieldErrorModel from "../model/FieldErrorModel";
import PersonalInfoModel from "../model/PersonalInfoModel";
import PersonalInfoPage from "./PersonalInfo";

const ProfilePage = () => {
  const [expanded, setExpanded] = React.useState<string | false>(false);

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
      setExpanded(isExpanded ? panel : false);
    };


  //   const userId = 1;
  //   //const personalInfoUtility = PersonalInfoUtility();
  //   const initialPersonalInfo: PersonalInfoModel = {
  //     id: 0,
  //     firstName: "default",
  //     lastName: "default last name",
  //     emailAddress: "tee@test.com",
  //     mobileNumber: "1236897",
  //     phoneNumber: "",
  //     description: "",
  //     isActive: true,
  //     userId: userId,
  //   };
  
  //   const initialErrors: FieldErrorModel[] = [];
  //   const [personalInfo, setPersonalInfo] = useState<PersonalInfoModel>(initialPersonalInfo);
  //   const [errorInfo, setErrorInfo] = useState<FieldErrorModel[]>(initialErrors);
  
  //   interface PersonalInfoProps {
  //     errorInfo: FieldErrorModel[];
  //     personalInfo: PersonalInfoModel;
  //   }

  //   useEffect(() => {
  //     async function getPersonalInfo() {
  //       let response   = await getPersonalInfoByUserIdAsync(1);
  //       if (response.status ===200){
  //         if (response.data !== null) {
  //           alert(JSON.stringify(response.data));
  //           console.log(response.data);
  //           // setPersonalInfo({
  //           //   id: response.data.id,
  //           //   firstName: response.data.firstName ||       initialPersonalInfo.firstName,
  //           //   lastName: response.data.lastName || "",
  //           //   emailAddress: response.data.emailAddress || "",
  //           //   mobileNumber: response.data.mobileNumber || "",
  //           //   phoneNumber: response.data.phoneNumber || "",
  //           //   description: response.data.description || "",
  //           //   isActive: response.data.isActive,
  //           //   userId: response.data.userId
  //           // });
  //          // alert(JSON.stringify(response.data));
  //           setPersonalInfo(response.data);
  //          //alert( response.data!.lastName);
  //          //const firstName = response.data[0].firstName;
  //         // setPersonalInfo((pre)=>({...pre, firstName: response.data!.firstName, lastName: response.data!.lastName}));
  //         }
  //       }else{
  //         alert(response.message);
  //       }
  //     }
  //     getPersonalInfo();
  //   }, [userId,expanded]);
  
  //   const onTextFieldChanged = (event: React.ChangeEvent<HTMLInputElement>) => {
  //     const name = event.currentTarget.name;
  //     const value = event.currentTarget.value;
  
  //     setPersonalInfo((prev) => ({ ...prev, [name]: value }));
  
  //     // Remove error message for the current field
  //     setErrorInfo((prevErrors) => {
  //       const newErrors = prevErrors.filter((error) => error.fieldName !== name);
  //       return newErrors;
  //     });
  //   };
  //   const onPersonalInfoSave = async () => {
  //     if (isValidate()) {
  //       const response = await createPersonalInfoAsync(personalInfo);
  //       alert(JSON.stringify(response));
  //     } else {
  //       alert("fail");
  //     }
  //   };
  //   const isValidate = () => {
  //     const newErrors: FieldErrorModel[] = [];
  
  //     if (personalInfo.firstName === "") {
  //       newErrors.push({
  //         fieldName: "firstName",
  //         errorMessage: "Enter firts name",
  //       });
  //     }
  //     // Validate email address
  //     if (personalInfo.emailAddress.trim() === "") {
  //       newErrors.push({
  //         fieldName: "emailAddress",
  //         errorMessage: "Enter email address",
  //       });
  //     } else if (!isValidEmailAddress(personalInfo.emailAddress)) {
  //       newErrors.push({
  //         fieldName: "emailAddress",
  //         errorMessage: "Invalid email address",
  //       });
  //     }
  
  //     if (personalInfo.mobileNumber === "") {
  //       newErrors.push({
  //         fieldName: "mobileNumber",
  //         errorMessage: "Enter Mobile Number ",
  //       });
  //     }
  
  //     setErrorInfo(newErrors);
  //     return newErrors.length === 0;
  //   };

  return (
    <LayoutComponent>
      <h2>Profile</h2>
      <div>
        <Accordion
          expanded={expanded === "panel1"}
          onChange={handleChange("panel1")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1bh-content"
            id="panel1bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>
             Personal information
            </Typography>
          </AccordionSummary>
         
          <AccordionDetails>
            {/* <PersonalInfo errorInfo={errorInfo}  personalInfo = {personalInfo} /> */}
            <PersonalInfoPage />
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel2"}
          onChange={handleChange("panel2")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel2bh-content"
            id="panel2bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>Users</Typography>
            <Typography sx={{ color: "text.secondary" }}>
              You are currently not an owner
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Donec placerat, lectus sed mattis semper, neque lectus feugiat
              lectus, varius pulvinar diam eros in elit. Pellentesque convallis
              laoreet laoreet.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel3"}
          onChange={handleChange("panel3")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel3bh-content"
            id="panel3bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>
              Advanced settings
            </Typography>
            <Typography sx={{ color: "text.secondary" }}>
              Filtering has been entirely disabled for whole web server
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Nunc vitae orci ultricies, auctor nunc in, volutpat nisl. Integer
              sit amet egestas eros, vitae egestas augue. Duis vel est augue.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion
          expanded={expanded === "panel4"}
          onChange={handleChange("panel4")}
        >
          <AccordionSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel4bh-content"
            id="panel4bh-header"
          >
            <Typography sx={{ width: "33%", flexShrink: 0 }}>
              Personal data
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Nunc vitae orci ultricies, auctor nunc in, volutpat nisl. Integer
              sit amet egestas eros, vitae egestas augue. Duis vel est augue.
            </Typography>
          </AccordionDetails>
        </Accordion>
      </div>
    </LayoutComponent>
  );
};

export default ProfilePage;
